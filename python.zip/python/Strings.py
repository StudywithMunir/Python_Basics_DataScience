name="TonyStark"
print(name.upper())
print(name)
print(name.lower())
print(name)
print(name.find('y')) #returns a index where y is present
print(name.find('Y'))
print(name.find("Stark"))
print(name.find("stark"))
print(name.replace("TonyStark","Ironman"))
print(name)
#to check if a character/string is part of the main string
print("Stark"in name)
print("S"in name)
print("s"in name)