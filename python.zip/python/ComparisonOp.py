is_greater=1>5
is_lesser=1<5
 #1<=5
 #1>=5
is_not_equal=1!=5
is_equal=1==5

print(is_greater)
print(is_lesser)
print(is_not_equal)
print(is_equal)