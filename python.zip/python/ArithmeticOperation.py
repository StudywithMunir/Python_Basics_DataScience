# Arithmetic Operators

# Addition
print(5+6)
print(2 + 3 + 9)

# Subtraction
print(99 - 73)

# Multiplication
print(23.54 * -1432)

# Division
print(100 / 7)

# Division without floating Points
print(100 // 7)

# Modulus i.e, Remainder
print(100 % 7)

# Power Operator
print(5**2)

# Solving an Expression
print(((2 + 5) * (17 - 3)) / (4 ** 3))

"""
 i=5
 i=i+2
 i+=2
 i-=2
 i*=2
        """