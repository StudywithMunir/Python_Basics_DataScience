numbers = range(5)
print(numbers)