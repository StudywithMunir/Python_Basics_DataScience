#While Loop (iterates from 1 to 5)
i=1
while(i<=5):
    print(i)
    i=i+1

#For Loop(iterates from 0 to 5 bcz of range function Range(5 -> (0,5) 0 and 5 are excluded))
for i in range(5):
 print(i)
i = i+1