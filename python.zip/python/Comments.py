print(5+6)  #this is inline comment

# this comment takes the whole line
print(9+9)

"""
This is multiLine comment code inside this comment will not executed

print(9+9)

"""