my_favorite_number = 1
my_least_favorite_number = 5
a_neutral_number = 3

# Equal Operator
# Equality check - True
print(my_favorite_number == 1)

# Not Equal Operator
# Not equal check - False
print(a_neutral_number != 3)

# Greater
# Greater than check - False
print(my_favorite_number > my_least_favorite_number)

# Greater than or Equal
# Greater than or equal check - False
print(my_favorite_number >= 3)


# Less than
# Less than - False
print(3 + 6 < 9)

# Less then or Equal
# Less than or equal check - False
print(my_favorite_number + a_neutral_number <= 3)


# Storing Result in a Variable
cost_of_ice_bag = 1.25
is_ice_bag_expensive = cost_of_ice_bag >= 10
print("Is the ice bag expensive?", is_ice_bag_expensive)
