#  Sets are a collection of all unique elements.
#  Indexing is not supported in sets.

marks = {50,65,78,23}

mark = 0
for mark in marks:
    if(mark > len(marks)):
        print(f"Marks are: {marks}")
        
    