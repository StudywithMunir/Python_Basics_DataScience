# Example Problem 1:
# A grocery store sells a bag of ice for $1.25 and makes a 20% profit. 
# If it sells 500 bags of ice, how much total profit does it make?

price_of_ice_bag = 1.25
profit_margin = .2
total_bags = 500
total_profit = total_bags * (profit_margin*price_of_ice_bag)

print("The Grocery store makes: $",total_profit)